package qouteall.dimlib;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class DimLibUtil {
    
    public static final Gson GSON;
    
    public static long secondToNano(double second) {
        return (long) (second * 1000000000);
    }
    
    public static double nanoToSecond(long l) {
        return l / 1000000000.0;
    }
    
    static {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setPrettyPrinting();
        
        gsonBuilder.registerTypeAdapter(
            new TypeToken<class_5321<class_1937>>() {}.getType(),
            new DimensionIDJsonAdapter()
        );
        
        GSON = gsonBuilder.create();
    }
    
    private static class DimensionIDJsonAdapter
        implements JsonSerializer<class_5321<class_1937>>, JsonDeserializer<class_5321<class_1937>> {
        
        @Override
        public class_5321<class_1937> deserialize(
            JsonElement json, Type typeOfT, JsonDeserializationContext context
        ) throws JsonParseException {
            String str = json.getAsString();
            return class_5321.method_29179(
                class_7924.field_41223, class_2960.method_60654(str)
            );
        }
        
        @Override
        public JsonElement serialize(class_5321<class_1937> src, Type typeOfSrc, JsonSerializationContext context) {
            return new JsonPrimitive(src.method_29177().toString());
        }
    }
}
