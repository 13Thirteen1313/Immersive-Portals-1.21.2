package qouteall.dimlib;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1937;
import net.minecraft.class_2874;
import net.minecraft.class_5321;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;
import java.util.Set;

@Environment(EnvType.CLIENT)
public class ClientDimensionInfo {
    private static final Logger LOGGER = LogManager.getLogger();
    
    public static ImmutableSet<class_5321<class_1937>> dimensionIds;
    public static ImmutableMap<class_5321<class_1937>, class_5321<class_2874>> dimensionIdToType;
    
    public static Set<class_5321<class_1937>> getDimensionIds() {
        if (dimensionIds == null) {
            throw new IllegalStateException("The dimension info has not been synced yet");
        }
        return dimensionIds;
    }
    
    public static Map<class_5321<class_1937>, class_5321<class_2874>> getDimensionIdToType() {
        if (dimensionIdToType == null) {
            throw new IllegalStateException("The dimension info has not been synced yet");
        }
        return dimensionIdToType;
    }
    
    // this is invoked on networking thread (earlier than in client thread)
    static void accept(ImmutableMap<class_5321<class_1937>, class_5321<class_2874>> m) {
        dimensionIdToType = m;
        dimensionIds = dimensionIdToType.keySet();
    }
    
    public static void cleanup() {
        LOGGER.info("Cleaning up client dimension info");
        dimensionIds = null;
        dimensionIdToType = null;
    }
}
