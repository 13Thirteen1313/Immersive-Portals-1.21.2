package qouteall.dimlib.ducks;

import java.util.concurrent.Executor;
import net.minecraft.class_1937;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_5321;

public interface IMinecraftServer {
    
    class_32.class_5143 dimlib_getStorageSource();
    
    Executor dimlib_getExecutor();
    
    void dimlib_addDimensionToWorldMap(class_5321<class_1937> dim, class_3218 world);
    
    void dimlib_removeDimensionFromWorldMap(class_5321<class_1937> dimension);
    
    void dimlib_waitUntilNextTick();
    
    boolean dimlib_getCanDirectlyRegisterDimensions();
    
    boolean dimlib_getIsFinishedCreatingWorlds();
    
    void dimlib_addTask(Runnable task);
    
    void dimlib_processTasks();
}
