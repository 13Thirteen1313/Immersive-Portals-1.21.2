package qouteall.dimlib.ducks;

import net.minecraft.class_2960;

public interface IMappedRegistry {
    public boolean dimlib_forceRemove(class_2960 id);
    
    boolean dimlib_getIsFrozen();
    
    /**
     * Note: un-freeze is only safe when no place use its holder.
     */
    void dimlib_setIsFrozen(boolean cond);
}
