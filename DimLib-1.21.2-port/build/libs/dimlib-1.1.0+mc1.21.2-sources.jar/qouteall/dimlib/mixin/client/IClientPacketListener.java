package qouteall.dimlib.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_1937;
import net.minecraft.class_5321;
import net.minecraft.class_634;

@Mixin(class_634.class)
public interface IClientPacketListener {
    @Accessor("levels")
    void ip_setLevels(Set<class_5321<class_1937>> arg);
}
