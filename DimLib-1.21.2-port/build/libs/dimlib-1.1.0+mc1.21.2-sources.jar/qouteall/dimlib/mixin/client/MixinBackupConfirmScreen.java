package qouteall.dimlib.mixin.client;

import eu.midnightdust.lib.config.MidnightConfig;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import qouteall.dimlib.DimLibEntry;
import qouteall.dimlib.config.DimLibConfig;

import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_405;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_437;
import net.minecraft.class_5489;
import net.minecraft.class_7196;

@Mixin(class_405.class)
public class MixinBackupConfirmScreen extends class_437 {
    
    @Shadow
    @Final
    protected class_405.class_406 onProceed;
    @Shadow
    private class_4286 eraseCache;
    @Shadow
    private class_5489 message;
    @Unique
    private boolean dimlib_isExperimentalWarning = false;
    
    protected MixinBackupConfirmScreen(class_2561 title) {
        super(title);
        throw new RuntimeException();
    }
    
    /**
     * {@link class_7196#method_41898}
     */
    @SuppressWarnings("JavadocReference")
    @Inject(method = "<init>", at = @At("RETURN"))
    private void onInitEnd(
        Runnable runnable, class_405.class_406 listener,
        class_2561 component, class_2561 component2, boolean bl, CallbackInfo ci
    ) {
        dimlib_isExperimentalWarning = Objects.equals(
            component,
            class_2561.method_43471("selectWorld.backupQuestion.experimental")
        );
    }
    
    @Inject(method = "init", at = @At("RETURN"))
    private void onInitEnd(CallbackInfo ci) {
        if (dimlib_isExperimentalWarning) {
            int i = (this.message.method_30887() + 1) * 9;
            method_37063(class_4185
                .method_46430(
                    class_2561.method_43471(
                        "dimlib.i_know_what_i_am_doing_and_disable_warning"
                    ),
                    button -> {
                        DimLibConfig.suppressExperimentalWarning = true;
                        MidnightConfig.write(DimLibEntry.MODID);
                        
                        this.onProceed.proceed(false, this.eraseCache.method_20372());
                    }
                )
                .method_46434(
                    this.field_22789 / 2 - 200, 124 + i + 40,
                    400, 20
                )
                .method_46431()
            );
            
        }
    }
}
