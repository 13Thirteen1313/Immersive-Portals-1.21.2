package qouteall.dimlib.mixin.client;

import net.minecraft.class_310;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import qouteall.dimlib.ClientDimensionInfo;

@Mixin(class_310.class)
public class MixinMinecraft {
    @Inject(method = "updateLevelInEngines", at = @At("HEAD"))
    private void onClientReset(class_638 level, CallbackInfo ci) {
        if (level == null) {
            ClientDimensionInfo.cleanup();
        }
    }
}
