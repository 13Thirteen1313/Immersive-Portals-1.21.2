package qouteall.dimlib.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_2780;
import net.minecraft.class_2784;

@Mixin(class_2784.class)
public interface IEWorldBorder {
    @Accessor("listeners")
    List<class_2780> ip_getListeners();
}
