package qouteall.dimlib.mixin.common;

import com.google.common.collect.Maps;
import net.minecraft.class_1937;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_3738;
import net.minecraft.class_3949;
import net.minecraft.class_4093;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.lang3.Validate;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import qouteall.dimlib.api.DimensionAPI;
import qouteall.dimlib.ducks.IMinecraftServer;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

@Mixin(MinecraftServer.class)
public abstract class MixinMinecraftServer
    extends class_4093<class_3738> implements IMinecraftServer {
    
    public MixinMinecraftServer(String name) {
        super(name);
        throw new RuntimeException();
    }
    
    @Mutable
    @Shadow
    @Final
    private Map<class_5321<class_1937>, class_3218> levels;
    
    @Shadow
    public abstract boolean isStopped();
    
    @Shadow
    public abstract boolean isDedicatedServer();
    
    @Shadow
    @Final
    protected class_32.class_5143 storageSource;
    
    @Shadow
    @Final
    private Executor executor;
    
    @Shadow
    protected abstract void waitUntilNextTick();
    
    @Unique
    private boolean ip_canDirectlyRegisterDimension = false;
    
    @Unique
    private boolean ip_finishedCreatingWorlds = false;
    
    @Unique
    private List<Runnable> dimlib_taskList;
    
    @Inject(method = "Lnet/minecraft/server/MinecraftServer;createLevels(Lnet/minecraft/server/level/progress/ChunkProgressListener;)V", at = @At("HEAD"))
    private void onBeforeCreateWorlds(
        class_3949 worldGenerationProgressListener, CallbackInfo ci
    ) {
        Validate.isTrue(
            !ip_canDirectlyRegisterDimension, "invalid server initialization status"
        );
        ip_canDirectlyRegisterDimension = true;
        
        DimensionAPI.SERVER_DIMENSIONS_LOAD_EVENT.invoker().run(
            (MinecraftServer) (Object) this
        );
        
        ip_canDirectlyRegisterDimension = false;
    }
    
    @Inject(
        method = "Lnet/minecraft/server/MinecraftServer;createLevels(Lnet/minecraft/server/level/progress/ChunkProgressListener;)V",
        at = @At("RETURN")
    )
    private void onFinishedLoadingAllWorlds(
        CallbackInfo ci
    ) {
        ip_finishedCreatingWorlds = true;
    }
    
    @Override
    public void dimlib_addDimensionToWorldMap(class_5321<class_1937> dim, class_3218 world) {
        // use read-copy-update to avoid concurrency issues
        LinkedHashMap<class_5321<class_1937>, class_3218> newMap =
            Maps.<class_5321<class_1937>, class_3218>newLinkedHashMap();
        
        Map<class_5321<class_1937>, class_3218> oldMap = this.levels;
        
        newMap.putAll(oldMap);
        newMap.put(dim, world);
        
        this.levels = newMap;
    }
    
    @Override
    public void dimlib_removeDimensionFromWorldMap(class_5321<class_1937> dimension) {
        // use read-copy-update to avoid concurrency issues
        LinkedHashMap<class_5321<class_1937>, class_3218> newMap =
            Maps.<class_5321<class_1937>, class_3218>newLinkedHashMap();
        
        Map<class_5321<class_1937>, class_3218> oldMap = this.levels;
        
        for (Map.Entry<class_5321<class_1937>, class_3218> entry : oldMap.entrySet()) {
            if (entry.getKey() != dimension) {
                newMap.put(entry.getKey(), entry.getValue());
            }
        }
        
        this.levels = newMap;
    }
    
    @Override
    public boolean dimlib_getCanDirectlyRegisterDimensions() {
        return ip_canDirectlyRegisterDimension;
    }
    
    @Override
    public boolean dimlib_getIsFinishedCreatingWorlds() {
        return ip_finishedCreatingWorlds;
    }
    
    @Override
    public class_32.class_5143 dimlib_getStorageSource() {
        return storageSource;
    }
    
    @Override
    public Executor dimlib_getExecutor() {
        return executor;
    }
    
    @Override
    public void dimlib_waitUntilNextTick() {
        Validate.isTrue(!method_18860());
        
        waitUntilNextTick();
    }
    
    @Override
    public void dimlib_addTask(Runnable task) {
        if (dimlib_taskList == null) {
            dimlib_taskList = new ArrayList<>();
        }
        
        dimlib_taskList.add(task);
    }
    
    @Override
    public void dimlib_processTasks() {
        if (dimlib_taskList != null) {
            for (Runnable task : dimlib_taskList) {
                task.run();
            }
            dimlib_taskList = null;
        }
    }
}
