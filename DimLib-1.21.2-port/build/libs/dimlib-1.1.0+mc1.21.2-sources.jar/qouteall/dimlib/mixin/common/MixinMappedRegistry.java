package qouteall.dimlib.mixin.common;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.Lifecycle;
import it.unimi.dsi.fastutil.objects.ObjectList;
import it.unimi.dsi.fastutil.objects.Reference2IntMap;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import qouteall.dimlib.ducks.IMappedRegistry;

import java.util.List;
import java.util.Map;
import net.minecraft.class_2370;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9248;

@Mixin(class_2370.class)
public abstract class MixinMappedRegistry<T> implements IMappedRegistry {
    @Shadow
    @Final
    private Map<class_2960, class_6880.class_6883<T>> byLocation;
    
    private static final Logger LOGGER = LogUtils.getLogger();
    
    @Shadow
    public abstract @Nullable T byId(int id);
    
    @Shadow
    @Final
    private ObjectList<class_6880.class_6883<T>> byId;
    
    @Shadow
    @Final
    private Reference2IntMap<T> toId;
    
    @Shadow
    @Final
    private Map<class_5321<T>, class_6880.class_6883<T>> byKey;
    
    @Shadow
    @Final
    class_5321<? extends class_2378<T>> key;
    
    @Shadow
    @Final
    private Map<T, class_6880.class_6883<T>> byValue;
    
    @Shadow
    private boolean frozen;
    
    @Shadow
    @Final
    private Map<class_5321<T>, class_9248> registrationInfos;
    
    @Override
    public boolean dimlib_getIsFrozen() {
        return frozen;
    }
    
    @Override
    public void dimlib_setIsFrozen(boolean cond) {
        frozen = cond;
    }
    
    /**
     * See {@link class_2370#method_10272(class_5321, Object, class_9248)}
     */
    @Override
    public boolean dimlib_forceRemove(class_2960 id) {
        LOGGER.debug("[DimLib] Trying to remove {} from {}", id, this.key);
        
        class_6880.class_6883<T> holder = byLocation.remove(id);
        
        if (holder == null) {
            LOGGER.debug("[DimLib] {} not found in {} when trying to remove", id, this.key);
            return false;
        }
        
        class_5321<T> eleKey = holder.method_40237();
        T value = holder.comp_349();
        
        int intId = toId.getInt(value);
        
        if (intId == -1) {
            LOGGER.error("[DimLib] missing integer id for {} {}", value, id);
        }
        else {
            toId.removeInt(value);
            byId.set(intId, null);
        }
        
        byKey.remove(eleKey);
        byValue.remove(value);
        registrationInfos.remove(eleKey);
        
        return true;
    }
    
}
