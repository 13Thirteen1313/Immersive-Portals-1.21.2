package qouteall.dimlib.mixin.common;

import com.mojang.serialization.Lifecycle;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_7723;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import qouteall.dimlib.DimensionImpl;

@Mixin(class_7723.class)
public class MixinWorldDimensions {
    // hack lifecycle
    @Inject(
        method = "isVanillaLike", at = @At("RETURN"), cancellable = true
    )
    private static void onIsVanillaLike(
        class_5321<class_5363> resourceKey, class_5363 levelStem, CallbackInfoReturnable<Boolean> cir
    ) {
        String namespace = resourceKey.method_29177().method_12836();
        if (DimensionImpl.STABLE_NAMESPACES.contains(namespace)) {
            cir.setReturnValue(true);
        }
    }
    
    // hack lifecycle
    @Redirect(
        method = "bake",
        at = @At(
            value = "INVOKE",
            target = "Lcom/mojang/serialization/Lifecycle;experimental()Lcom/mojang/serialization/Lifecycle;",
            remap = false
        )
    )
    private Lifecycle redirectLifecycle() {
        return Lifecycle.stable();
    }
}
