package qouteall.dimlib.mixin.common;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2535;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_8792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import qouteall.dimlib.DimLibNetworking;

@Mixin(class_3324.class)
public class MixinPlayerList {
    // send it right after login packet
    @Inject(
        method = "placeNewPlayer",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/network/protocol/game/ClientboundChangeDifficultyPacket;<init>(Lnet/minecraft/world/Difficulty;Z)V"
        )
    )
    private void onConnectionEstablished(
        class_2535 connection,
        class_3222 player,
        class_8792 commonListenerCookie,
        CallbackInfo ci
    ) {
        player.field_13987.method_14364(
            ServerPlayNetworking.createS2CPacket(
                DimLibNetworking.DimSyncPacket.createPacket(player.field_13995)
            )
        );
    }
}
