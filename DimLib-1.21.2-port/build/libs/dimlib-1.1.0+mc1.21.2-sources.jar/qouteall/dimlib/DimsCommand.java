package qouteall.dimlib;

import com.google.gson.JsonElement;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2181;
import net.minecraft.class_2370;
import net.minecraft.class_2561;
import net.minecraft.class_2794;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5250;
import net.minecraft.class_5363;
import net.minecraft.class_6903;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import qouteall.dimlib.api.DimensionAPI;

import java.util.List;
import java.util.stream.Collectors;

public class DimsCommand {
    private static final Logger LOGGER = LogUtils.getLogger();
    
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        LiteralArgumentBuilder<class_2168> builder = class_2170
            .method_9247("dims")
            .requires(source -> source.method_9259(2));
        
        builder.then(class_2170
            .method_9247("clone_dimension")
            .then(class_2170.method_9244("templateDimension", class_2181.method_9288())
                .then(class_2170.method_9244("newDimensionID", StringArgumentType.string())
                    .executes(context -> {
                        class_3218 templateDimension =
                            class_2181.method_9289(context, "templateDimension");
                        String newDimensionId = StringArgumentType.getString(context, "newDimensionID");
                        
                        class_2960 newDimId = parseDimensionId(context, newDimensionId);
                        
                        if (newDimId == null) {
                            return 0;
                        }
                        
                        cloneDimension(
                            templateDimension, newDimId
                        );
                        
                        context.getSource().method_9226(() -> class_2561.method_43470(
                            "Dynamically added dimension %s".formatted(newDimensionId)
                        ), true);
                        
                        return 0;
                    })
                )
            )
        );
        
        // to make q_misc_util be able to work server-only
        // we cannot use custom command argument type
        RequiredArgumentBuilder<class_2168, String> addDimensionCommandNode =
            class_2170.method_9244("newDimensionId", StringArgumentType.string());
        
        for (var e : DimensionTemplate.DIMENSION_TEMPLATES.entrySet()) {
            String dimTemplateId = e.getKey();
            DimensionTemplate dimensionTemplate = e.getValue();
            addDimensionCommandNode.then(class_2170.method_9247(dimTemplateId)
                .executes(context -> {
                    return runAddDimension(context, dimensionTemplate);
                })
            );
        }
        
        builder.then(class_2170.method_9247("add_dimension")
            .then(addDimensionCommandNode)
        );
        
        builder.then(class_2170
            .method_9247("remove_dimension")
            .then(class_2170.method_9244("dimension", class_2181.method_9288())
                .executes(context -> {
                    class_3218 dimension =
                        class_2181.method_9289(context, "dimension");
                    
                    DimensionAPI.removeDimensionDynamically(dimension);
                    
                    context.getSource().method_9226(() -> class_2561.method_43470(
                        ("Dynamically removed dimension %s . Its world file is not yet deleted. " +
                            "Note: if the datapack config for that dimension exists, the dimension will be re-added after server restart.")
                            .formatted(dimension.method_27983().method_29177())
                    ), true);
                    
                    return 0;
                })
            )
        );
        
        builder.then(class_2170.method_9247("list")
            .executes(context -> {
                MinecraftServer server = context.getSource().method_9211();
                
                class_5250 text = class_2561.method_43470(
                    server.method_29435()
                        .stream()
                        .map(k -> k.method_29177().toString())
                        .sorted()
                        .collect(Collectors.joining("\n"))
                );
                
                context.getSource().method_9226(() -> text, false);
                
                return 0;
            }));
        
        builder.then(class_2170.method_9247("view_dim_config")
            .then(class_2170.method_9244("dim", class_2181.method_9288())
                .executes(context -> {
                    class_3218 world =
                        class_2181.method_9289(context, "dim");
                    
                    class_2370<class_5363> dimensionRegistry =
                        DimensionImpl.getDimensionRegistry(world.method_8503());
                    
                    class_5363 levelStem = dimensionRegistry.method_63535(world.method_27983().method_29177());
                    
                    if (levelStem == null) {
                        context.getSource().method_9213(
                            class_2561.method_43470("Dimension config not found")
                        );
                        return 0;
                    }
                    
                    DataResult<JsonElement> encoded = class_5363.field_25411.encodeStart(
                        class_6903.method_46632(JsonOps.INSTANCE, world.method_30349()),
                        levelStem
                    );
                    
                    if (encoded.result().isPresent()) {
                        String jsonStr = DimLibUtil.GSON.toJson(encoded.result().get());
                        
                        context.getSource().method_9226(
                            () -> class_2561.method_43470(jsonStr),
                            true
                        );
                    }
                    else {
                        context.getSource().method_9213(class_2561.method_43470(
                            encoded.error().toString()
                        ));
                    }
                    
                    return 0;
                })
            )
        );
        
        dispatcher.register(builder);
    }
    
    @Nullable
    private static class_2960 parseDimensionId(
        CommandContext<class_2168> context, String newDimensionId
    ) {
        class_2960 newDimId;
        try {
            newDimId = class_2960.method_60654(newDimensionId);
        }
        catch (Exception e) {
            context.getSource().method_9213(class_2561.method_43470("Invalid dimension id"));
            return null;
        }
        
        MinecraftServer server = context.getSource().method_9211();
        
        if (newDimId.method_12836().equals("minecraft")) {
            context.getSource().method_9213(
                class_2561.method_43470("namespace cannot be minecraft")
            );
            return null;
        }
        
        if (DimensionAPI.dimensionExistsInRegistry(server, newDimId)) {
            context.getSource().method_9213(
                class_2561.method_43470("Dimension" + newDimId + " already exists")
            );
            return null;
        }
        
        return newDimId;
    }
    
    private static int runAddDimension(
        CommandContext<class_2168> context, DimensionTemplate template
    ) {
        String newDimensionId = StringArgumentType.getString(
            context, "newDimensionId"
        );
        
        class_2960 newDimId = parseDimensionId(context, newDimensionId);
        
        if (newDimId == null) {
            return 0;
        }
        
        MinecraftServer server = context.getSource().method_9211();
        
        DimensionAPI.addDimensionDynamically(
            server,
            newDimId,
            template.createLevelStem(server)
        );
        
        return 0;
    }
    
    private static void cloneDimension(
        class_3218 templateDimension, class_2960 newDimId
    ) {
        // may throw exception here
        
        class_2794 generator = templateDimension.method_14178().method_12129();
        
        DimensionAPI.addDimension(
            templateDimension.method_8503(),
            newDimId,
            new class_5363(
                templateDimension.method_40134(),
                generator
            )
        );
    }
    
}
