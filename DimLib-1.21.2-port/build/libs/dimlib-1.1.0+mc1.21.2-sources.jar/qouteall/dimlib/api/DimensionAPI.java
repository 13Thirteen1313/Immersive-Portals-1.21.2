package qouteall.dimlib.api;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1937;
import net.minecraft.class_2874;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5219;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_5455;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import qouteall.dimlib.ClientDimensionInfo;
import qouteall.dimlib.DimensionImpl;
import qouteall.dimlib.DimensionTemplate;
import qouteall.dimlib.DynamicDimensionsImpl;
import qouteall.dimlib.ducks.IMinecraftServer;

import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;

public class DimensionAPI {
    private static final Logger LOGGER = LogManager.getLogger();
    
    /**
     * See {@link DimensionAPI#SERVER_DIMENSIONS_LOAD_EVENT}
     */
    public static interface ServerDimensionsLoadCallback {
        void run(MinecraftServer server);
    }
    
    /**
     * This event is fired when loading custom dimensions when the server is starting.
     * Inside this event, you can:
     * - use {@link MinecraftServer#method_30611()} and {@link class_5455#method_30530(class_5321)} to access registries (including dimension type registry)
     * - use {@link MinecraftServer#method_27728()} {@link class_5219#method_28057()} to access world information like seed.
     * - use {@link DimensionAPI#addDimension(MinecraftServer, class_2960, class_5363)} to add dimension.
     */
    public static final Event<ServerDimensionsLoadCallback> SERVER_DIMENSIONS_LOAD_EVENT =
        EventFactory.createArrayBacked(
            ServerDimensionsLoadCallback.class,
            (listeners) -> ((server) -> {
                for (ServerDimensionsLoadCallback listener : listeners) {
                    try {
                        listener.run(server);
                    }
                    catch (Exception e) {
                        LOGGER.error("Error during server dimensions load event", e);
                    }
                }
            })
        );
    
    /**
     * Add a new dimension.
     * Can be used both when server is running or during {@link DimensionAPI#SERVER_DIMENSIONS_LOAD_EVENT}.
     * Note: Should not register a dimension that already exists.
     * The added dimension's config will be saved into `level.dat`
     */
    public static void addDimension(
        MinecraftServer server,
        class_2960 dimensionId,
        class_5363 levelStem
    ) {
        if (((IMinecraftServer) server).dimlib_getIsFinishedCreatingWorlds()) {
            addDimensionDynamically(server, dimensionId, levelStem);
        }
        else {
            if (((IMinecraftServer) server).dimlib_getCanDirectlyRegisterDimensions()) {
                DimensionImpl.directlyRegisterLevelStem(server, dimensionId, levelStem);
            }
            else {
                LOGGER.error(
                    "Cannot add dimension at this time {}", dimensionId, new Throwable()
                );
            }
        }
    }
    
    /**
     * Check if a dimension exists in registry.
     * This can be used when the server worlds are not yet initialized.
     */
    public static boolean dimensionExistsInRegistry(
        MinecraftServer server, class_2960 dimensionId
    ) {
        // if the server is not yet running, getLevel() doesn't work
        return DimensionImpl.getDimensionRegistry(server).method_10250(dimensionId);
    }
    
    /**
     * Similar to {@link DimensionAPI#addDimension(MinecraftServer, class_2960, class_5363)},
     * but will not add the dimension if it already exists.
     */
    public static void addDimensionIfNotExists(
        MinecraftServer server,
        class_2960 dimensionId,
        Supplier<class_5363> levelStem
    ) {
        if (dimensionExistsInRegistry(server, dimensionId)) {
            return;
        }
        
        addDimension(server, dimensionId, levelStem.get());
    }
    
    /**
     * Add a new dimension when the server is running.
     * Can only be used when server is running.
     * The new dimension's config will be saved in the `level.dat` file.
     */
    public static void addDimensionDynamically(
        MinecraftServer server,
        class_2960 dimensionId,
        class_5363 levelStem
    ) {
        Validate.isTrue(server.method_3806(), "The server is not running");
        DynamicDimensionsImpl.addDimensionDynamically(server, dimensionId, levelStem);
    }
    
    /**
     * Remove a dimension dynamically.
     * Cannot be used during server initialization.
     * Cannot remove vanilla dimensions.
     * The removed dimension's config will be removed from the `level.dat` file.
     * Does not delete that dimension's world saving files.
     */
    public static void removeDimensionDynamically(class_3218 world) {
        if (!world.method_8503().method_3806()) {
            LOGGER.error(
                "Cannot remove dimension at this time {}", world, new Throwable()
            );
            return;
        }
        
        DynamicDimensionsImpl.removeDimensionDynamically(world);
    }
    
    /**
     * see {@link DimensionAPI#SERVER_DIMENSION_DYNAMIC_UPDATE_EVENT}
     */
    public static interface ServerDynamicUpdateListener {
        void run(MinecraftServer server, Set<class_5321<class_1937>> dimensions);
    }
    
    /**
     * see {@link DimensionAPI#CLIENT_DIMENSION_UPDATE_EVENT}
     */
    public static interface ClientDynamicUpdateListener {
        void run(Set<class_5321<class_1937>> dimensions);
    }
    
    /**
     * Will be triggered when the server dynamically add or remove a dimension.
     * Does not trigger during server initialization.
     */
    public static final Event<ServerDynamicUpdateListener> SERVER_DIMENSION_DYNAMIC_UPDATE_EVENT =
        EventFactory.createArrayBacked(
            ServerDynamicUpdateListener.class,
            arr -> (server, dims) -> {
                for (ServerDynamicUpdateListener listener : arr) {
                    try {
                        listener.run(server, dims);
                    }
                    catch (Exception e) {
                        LOGGER.error("Error during dimension update event", e);
                    }
                }
            }
        );
    
    /**
     * Will be triggered when the client receives dimension data synchronization.
     */
    public static final Event<ClientDynamicUpdateListener> CLIENT_DIMENSION_UPDATE_EVENT =
        EventFactory.createArrayBacked(
            ClientDynamicUpdateListener.class,
            arr -> (set) -> {
                for (ClientDynamicUpdateListener listener : arr) {
                    try {
                        listener.run(set);
                    }
                    catch (Exception e) {
                        LOGGER.error("Error during dimension update event", e);
                    }
                }
            }
        );
    
    /**
     * Is the dimension still in the server.
     * Can be used when the server is running.
     */
    public static boolean isDimensionAlive(class_3218 world) {
        return world.method_8503().method_3847(world.method_27983()) == world;
    }
    
    /**
     * Disable the "Worlds using Experimental Settings are not supported" warning screen.
     * This should be called during initialization.
     */
    public static void suppressExperimentalWarning() {
        DimensionImpl.suppressExperimentalWarning = true;
    }
    
    /**
     * Mark a namespace as "stable".
     * Then the dimensions with that namespace will not cause "Worlds using Experimental Settings are not supported" warning screen to appear (but other dimensions may do).
     * This is not needed if {@link DimensionAPI#suppressExperimentalWarning()} is called.
     * This should be called during initialization.
     */
    public static void suppressExperimentalWarningForNamespace(String namespace) {
        DimensionImpl.STABLE_NAMESPACES.add(namespace);
    }
    
    /**
     * @return The dimension ids. Can be called in client.
     */
    @Environment(EnvType.CLIENT)
    public static Set<class_5321<class_1937>> getClientDimensionIds() {
        return ClientDimensionInfo.getDimensionIds();
    }
    
    /**
     * @return The map from dimension id to dimension type id. Can be called in client.
     */
    @Environment(EnvType.CLIENT)
    public static Map<class_5321<class_1937>, class_5321<class_2874>> getClientDimensionIdToTypeMap() {
        return ClientDimensionInfo.getDimensionIdToType();
    }
    
    /**
     * The dimension templates are used in `/dims add_dimension` command.
     * Should register during initialization.
     * The name should not contain spaces.
     */
    public static void registerDimensionTemplate(
        String name, DimensionTemplate dimensionTemplate
    ) {
        DimensionTemplate.registerDimensionTemplate(name, dimensionTemplate);
    }
    
    /**
     * see {@link DimensionAPI#SERVER_PRE_REMOVE_DIMENSION_EVENT}
     */
    public static interface PreRemoveDimensionCallback {
        void accept(class_3218 world);
    }
    
    /**
     * This event is triggered right before dynamically removing a dimension on server.
     */
    public static final Event<PreRemoveDimensionCallback> SERVER_PRE_REMOVE_DIMENSION_EVENT =
        EventFactory.createArrayBacked(
            PreRemoveDimensionCallback.class,
            (listeners) -> ((world) -> {
                for (PreRemoveDimensionCallback listener : listeners) {
                    try {
                        listener.accept(world);
                    }
                    catch (Exception e) {
                        LOGGER.error("Error during before removing dimension event", e);
                    }
                }
            })
        );
}
