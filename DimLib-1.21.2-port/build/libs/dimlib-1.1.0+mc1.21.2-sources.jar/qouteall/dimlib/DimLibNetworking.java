package qouteall.dimlib;

import com.google.common.collect.ImmutableMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2602;
import net.minecraft.class_2874;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_7134;
import net.minecraft.class_7924;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.lang3.Validate;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import qouteall.dimlib.api.DimensionAPI;
import qouteall.dimlib.mixin.client.IClientPacketListener;

public class DimLibNetworking {
    public static final Logger LOGGER = LoggerFactory.getLogger(DimLibNetworking.class);
    
    public static record DimSyncPacket(
        class_2487 dimIdToTypeIdTag
    ) implements class_8710 {
        public static final class_8710.class_9154<DimSyncPacket> TYPE =
            new class_9154<>(class_2960.method_60654("dimlib:dim_sync"));
        
        public static final class_9139<class_2540, DimSyncPacket> CODEC =
            class_9139.method_56437((b, p) -> p.write(b), DimSyncPacket::read);
        
        public static DimSyncPacket read(class_2540 buf) {
            class_2487 compoundTag = buf.method_10798();
            return new DimSyncPacket(compoundTag);
        }
        
        public void write(class_2540 buf) {
            buf.method_10794(dimIdToTypeIdTag);
        }
        
        public static DimSyncPacket createPacket(MinecraftServer server) {
            class_5455 registryManager = server.method_30611();
            class_2378<class_2874> dimensionTypes = registryManager.method_30530(class_7924.field_41241);
            
            class_2487 dimIdToDimTypeId = new class_2487();
            for (class_3218 world : server.method_3738()) {
                class_5321<class_1937> dimId = world.method_27983();
                
                class_2874 dimType = world.method_8597();
                class_2960 dimTypeId = dimensionTypes.method_10221(dimType);
                
                if (dimTypeId == null) {
                    LOGGER.error("Cannot find dimension type for {}", dimId.method_29177());
                    LOGGER.error(
                        "Registered dimension types {}", dimensionTypes.method_10235()
                    );
                    dimTypeId = class_7134.field_37666.method_29177();
                }
                
                dimIdToDimTypeId.method_10582(
                    dimId.method_29177().toString(),
                    dimTypeId.toString()
                );
            }
            
            return new DimSyncPacket(dimIdToDimTypeId);
        }
        
        public ImmutableMap<class_5321<class_1937>, class_5321<class_2874>> toMap() {
            class_2487 tag = dimIdToTypeIdTag();
            
            ImmutableMap.Builder<class_5321<class_1937>, class_5321<class_2874>> builder =
                new ImmutableMap.Builder<>();
            
            for (String key : tag.method_10541()) {
                class_5321<class_1937> dimId = class_5321.method_29179(
                    class_7924.field_41223,
                    class_2960.method_60654(key)
                );
                String dimTypeId = tag.method_10558(key);
                class_5321<class_2874> dimType = class_5321.method_29179(
                    class_7924.field_41241,
                    class_2960.method_60654(dimTypeId)
                );
                builder.put(dimId, dimType);
            }
            
            return builder.build();
        }
        
        @Environment(EnvType.CLIENT)
        public void handle(class_2602 listener) {
            Validate.isTrue(
                class_310.method_1551().method_18854(),
                "Not running in client thread"
            );
            
            LOGGER.info(
                "Client received dimension info\n{}",
                String.join("\n", dimIdToTypeIdTag.method_10541())
            );
            
            var dimIdToDimType = this.toMap();
            ClientDimensionInfo.accept(dimIdToDimType);
            ((IClientPacketListener) listener).ip_setLevels(dimIdToDimType.keySet());
            
            DimensionAPI.CLIENT_DIMENSION_UPDATE_EVENT.invoker().run(
                ClientDimensionInfo.getDimensionIds()
            );
        }
        
        @Override
        public @NotNull class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }
    
    public static void init() {
        PayloadTypeRegistry.playS2C().register(
            DimSyncPacket.TYPE, DimSyncPacket.CODEC
        );
    }
    
    @SuppressWarnings("resource")
    @Environment(EnvType.CLIENT)
    public static void initClient() {
        ClientPlayNetworking.registerGlobalReceiver(
            DimSyncPacket.TYPE,
            (p, c) -> {
                // it's now handled in client thread, not networking thread
                p.handle(c.client().method_1562());
            }
        );
    }
}
