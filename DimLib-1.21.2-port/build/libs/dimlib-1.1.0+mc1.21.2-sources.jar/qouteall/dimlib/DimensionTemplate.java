package qouteall.dimlib;

import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_2246;
import net.minecraft.class_2378;
import net.minecraft.class_2874;
import net.minecraft.class_2897;
import net.minecraft.class_3229;
import net.minecraft.class_3232;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7134;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public record DimensionTemplate(
    class_5321<class_2874> dimensionTypeId,
    DimensionFactory dimensionFactory
) {
    
    public static interface DimensionFactory {
        class_5363 createLevelStem(
            MinecraftServer server,
            class_6880<class_2874> dimensionTypeHolder
        );
    }
    
    static final Map<String, DimensionTemplate> DIMENSION_TEMPLATES = new LinkedHashMap<>();
    
    public static void registerDimensionTemplate(
        String name, DimensionTemplate dimensionTemplate
    ) {
        DIMENSION_TEMPLATES.put(name, dimensionTemplate);
    }
    
    public class_5363 createLevelStem(MinecraftServer server) {
        class_2378<class_2874> dimensionTypes =
            server.method_30611().method_30530(class_7924.field_41241);
        
        class_6880.class_6883<class_2874> holder =
            dimensionTypes.method_46747(dimensionTypeId);
        
        return dimensionFactory.createLevelStem(
            server, holder
        );
    }
    
    public static void init() {
        registerDimensionTemplate(
            "void", VOID_TEMPLATE
        );
    }
    
    public static final DimensionTemplate VOID_TEMPLATE = new DimensionTemplate(
        class_7134.field_37666,
        (server, dimTypeHolder) -> {
            class_5455.class_6890 registryAccess = server.method_30611();
            
            class_2378<class_1959> biomeRegistry = registryAccess.method_30530(class_7924.field_41236);
            
            class_6880.class_6883<class_1959> plainsHolder = biomeRegistry.method_46747(class_1972.field_9451);
            
            class_3232 flatChunkGeneratorConfig =
                new class_3232(
                    Optional.of(class_6885.method_40246()),
                    plainsHolder,
                    List.of()
                );
            flatChunkGeneratorConfig.method_14327().add(new class_3229(1, class_2246.field_10124));
            flatChunkGeneratorConfig.method_14330();
            
            class_2897 chunkGenerator = new class_2897(flatChunkGeneratorConfig);
            
            return new class_5363(dimTypeHolder, chunkGenerator);
        }
    );
}
