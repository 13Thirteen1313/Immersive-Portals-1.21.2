package qouteall.dimlib;

import com.google.common.collect.ImmutableList;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.Lifecycle;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2370;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_27;
import net.minecraft.class_2709;
import net.minecraft.class_2780;
import net.minecraft.class_2784;
import net.minecraft.class_2806;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3949;
import net.minecraft.class_4543;
import net.minecraft.class_5219;
import net.minecraft.class_5268;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_7924;
import net.minecraft.class_8705;
import net.minecraft.class_9248;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;
import qouteall.dimlib.api.DimensionAPI;
import qouteall.dimlib.ducks.IMappedRegistry;
import qouteall.dimlib.ducks.IMinecraftServer;
import qouteall.dimlib.mixin.common.IEWorldBorder;

import java.io.IOException;
import java.util.List;
import java.util.Set;

public class DynamicDimensionsImpl {
    private static final Logger LOGGER = LogManager.getLogger();
    
    public static boolean isRemovingDimension = false;
    
    public static void init() {
    
    }
    
    public static void addDimensionDynamically(
        MinecraftServer server,
        class_2960 dimensionId,
        class_5363 levelStem
    ) {
        /**{@link MinecraftServer#createLevels(ChunkProgressListener)}*/
        
        class_5321<class_1937> dimensionResourceKey = class_5321.method_29179(
            class_7924.field_41223, dimensionId
        );
        
        Validate.isTrue(server.method_18854(), "this should be called in server main thread");
        Validate.isTrue(server.method_3806(), "Server is not running");
        
        if (server.method_3847(dimensionResourceKey) != null) {
            throw new RuntimeException("Dimension " + dimensionId + " already exists.");
        }
        
        class_3218 overworld = server.method_3847(class_1937.field_25179);
        Validate.notNull(overworld, "Overworld is null");
        class_2784 worldBorder = overworld.method_8621();
        Validate.notNull(worldBorder, "Overworld world border is null");
        
        class_5219 worldData = server.method_27728();
        class_5268 serverLevelData = worldData.method_27859();
        
        long seed = worldData.method_28057().method_28028();
        long obfuscatedSeed = class_4543.method_27984(seed);
        
        class_27 derivedLevelData = new class_27(
            worldData, serverLevelData
        );
        
        class_3218 newWorld = new class_3218(
            server,
            ((IMinecraftServer) server).dimlib_getExecutor(),
            ((IMinecraftServer) server).dimlib_getStorageSource(),
            derivedLevelData,
            dimensionResourceKey,
            levelStem,
            new DummyProgressListener(),
            false, // isDebug
            obfuscatedSeed,
            ImmutableList.of(),
            false, // only true for overworld
            overworld.method_52168()
        );
        
        worldBorder.method_11983(
            new class_2780.class_3976(newWorld.method_8621())
        );
        
        ((IMinecraftServer) server).dimlib_addDimensionToWorldMap(dimensionResourceKey, newWorld);
        
        /**
         * register it into registry, so it will be saved in
         * {@link WorldGenSettings#encode(DynamicOps, WorldOptions, RegistryAccess)} ,
         * so it will be saved into level.dat
         * */
        class_2378<class_5363> levelStemRegistry = server.method_30611().method_30530(class_7924.field_41224);
        ((IMappedRegistry) levelStemRegistry).dimlib_setIsFrozen(false);
        ((class_2370<class_5363>) levelStemRegistry).method_10272(
            class_5321.method_29179(class_7924.field_41224, dimensionId),
            levelStem,
            class_9248.field_49136 // use built-in registration info for now
        );
        ((IMappedRegistry) levelStemRegistry).dimlib_setIsFrozen(true);
        
        worldBorder.method_17905(serverLevelData.method_27422());
        
        LOGGER.info("Added Dimension {}", dimensionId);
        
        var dimSyncPacket = ServerPlayNetworking.createS2CPacket(
            DimLibNetworking.DimSyncPacket.createPacket(server)
        );
        for (class_3222 player : server.method_3760().method_14571()) {
            player.field_13987.method_14364(dimSyncPacket);
        }
        
        DimensionAPI.SERVER_DIMENSION_DYNAMIC_UPDATE_EVENT.invoker().run(server, server.method_29435());
    }
    
    public static void removeDimensionDynamically(class_3218 world) {
        MinecraftServer server = world.method_8503();
        
        Validate.isTrue(server.method_18854());
        
        class_5321<class_1937> dimension = world.method_27983();
        
        if (dimension == class_1937.field_25179 || dimension == class_1937.field_25180 || dimension == class_1937.field_25181) {
            throw new RuntimeException("Cannot remove vanilla dimension");
        }
        
        Validate.isTrue(server.method_3806(), "Server is not running");
        
        LOGGER.info("Started Removing Dimension {}", dimension.method_29177());
        
        ((IMinecraftServer) server).dimlib_addTask(() -> {
            DimensionAPI.SERVER_PRE_REMOVE_DIMENSION_EVENT.invoker().accept(world);
            
            evacuatePlayersFromDimension(world);
            
            /**{@link MinecraftServer#stopServer()}*/
            
            long startTime = System.nanoTime();
            long lastLogTime = System.nanoTime();
            
            isRemovingDimension = true;
            
            ((IMinecraftServer) server).dimlib_removeDimensionFromWorldMap(dimension);
            
            try {
                while (world.method_14178().field_17254.method_39992()) {
                    world.method_14178().method_39997();
                    world.method_14178().method_12127(() -> true, false);
                    world.method_14178().method_19492();
                    server.method_16075();
                    
                    if (System.nanoTime() - lastLogTime > DimLibUtil.secondToNano(1)) {
                        lastLogTime = System.nanoTime();
                        LOGGER.info("waiting for chunk tasks to finish");
                    }
                    
                    if (System.nanoTime() - startTime > DimLibUtil.secondToNano(15)) {
                        LOGGER.error("Waited too long for chunk tasks");
                        break;
                    }
                    
                    ((IMinecraftServer) server).dimlib_waitUntilNextTick();
                }
            }
            catch (Throwable e) {
                LOGGER.error("Error when waiting for chunk tasks", e);
            }
            
            isRemovingDimension = false;
            
            LOGGER.info(
                "Finished chunk tasks in {} seconds",
                DimLibUtil.nanoToSecond(System.nanoTime() - startTime)
            );
            
            LOGGER.info(
                "Chunk num: {}     Has entities: {}",
                world.method_14178().field_17254.method_17260(),
                world.method_27909().iterator().hasNext()
            );
            
            server.method_3723(false, true, false);
            
            try {
                world.close();
            }
            catch (IOException e) {
                LOGGER.error("Error when closing world", e);
            }
            
            resetWorldBorderListener(server);
            
            // force remove it from registry, so it will not be saved into level.dat
            class_2378<class_5363> levelStemRegistry = server.method_30611()
                .method_30530(class_7924.field_41224);
            ((IMappedRegistry) levelStemRegistry).dimlib_forceRemove(dimension.method_29177());
            
            LOGGER.info("Removed Dimension {}", dimension.method_29177());
            
            class_2596<class_8705> dimSyncPacket = ServerPlayNetworking.createS2CPacket(
                DimLibNetworking.DimSyncPacket.createPacket(server)
            );
            for (class_3222 player : server.method_3760().method_14571()) {
                player.field_13987.method_14364(dimSyncPacket);
            }
            
            DimensionAPI.SERVER_DIMENSION_DYNAMIC_UPDATE_EVENT.invoker().run(server, server.method_29435());
        });
    }
    
    private static void resetWorldBorderListener(MinecraftServer server) {
        class_3218 overworld = server.method_3847(class_1937.field_25179);
        Validate.notNull(overworld, "Overworld is null");
        
        class_2784 worldBorder = overworld.method_8621();
        List<class_2780> borderChangeListeners =
            ((IEWorldBorder) worldBorder).ip_getListeners();
        borderChangeListeners.clear();
        for (class_3218 serverWorld : server.method_3738()) {
            if (serverWorld != overworld) {
                worldBorder.method_11983(
                    new class_2780.class_3976(serverWorld.method_8621())
                );
            }
        }
        server.method_3760().method_14591(overworld);
    }
    
    private static void evacuatePlayersFromDimension(class_3218 world) {
        MinecraftServer server = world.method_8503();
        class_3218 overworld = server.method_3847(class_1937.field_25179);
        Validate.notNull(overworld, "Overworld is null");
        
        List<class_3222> players = world.method_18766(p -> true);
        
        class_2338 sharedSpawnPos = overworld.method_43126();
        
        for (class_3222 player : players) {
            player.method_48105(
                overworld,
                sharedSpawnPos.method_10263(), sharedSpawnPos.method_10264(), sharedSpawnPos.method_10260(),
                Set.<class_2709>of(), 0, 0, false
            );
            player.method_64398(
                class_2561.method_43470(
                    "Teleported to spawn pos because dimension %s had been removed"
                        .formatted(world.method_27983().method_29177())
                )
            );
        }
    }
    
    private static class DummyProgressListener implements class_3949 {
        
        @Override
        public void method_17669(class_1923 center) {
        
        }
        
        @Override
        public void method_17670(class_1923 chunkPosition, @Nullable class_2806 newStatus) {
        
        }
        
        @Override
        public void method_17675() {
        
        }
        
        @Override
        public void method_17671() {
        
        }
    }
    
}
