package qouteall.dimlib;

import com.mojang.serialization.Lifecycle;
import net.minecraft.class_2370;
import net.minecraft.class_2960;
import net.minecraft.class_5219;
import net.minecraft.class_5285;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_5455;
import net.minecraft.class_7924;
import net.minecraft.class_9248;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import qouteall.dimlib.ducks.IMappedRegistry;

import java.util.HashSet;

public class DimensionImpl {
    
    public static final Logger LOGGER = LoggerFactory.getLogger(DimensionImpl.class);
    
    public static final HashSet<String> STABLE_NAMESPACES = new HashSet<>();
    public static boolean suppressExperimentalWarning = false;
    
    public static void directlyRegisterLevelStem(
        MinecraftServer server, class_2960 dimensionId, class_5363 levelStem
    ) {
        class_5455.class_6890 registryAccess = server.method_30611();
        
        class_5219 worldData = server.method_27728();
        class_5285 worldOptions = worldData.method_28057();
        
        class_2370<class_5363> levelStems = (class_2370<class_5363>)
            registryAccess.method_30530(class_7924.field_41224);
        
        if (!levelStems.method_10250(dimensionId)) {
            // the vanilla freezing mechanism is used for validating dangling object references
            // for this API, that thing won't happen
            boolean oldIsFrozen = ((IMappedRegistry) levelStems).dimlib_getIsFrozen();
            ((IMappedRegistry) levelStems).dimlib_setIsFrozen(false);
            
            try {
                levelStems.method_10272(
                    class_5321.method_29179(class_7924.field_41224, dimensionId),
                    levelStem,
                    class_9248.field_49136 // use built-in registration info for now
                );
            }
            finally {
                ((IMappedRegistry) levelStems).dimlib_setIsFrozen(oldIsFrozen);
            }
        }
        else {
            LOGGER.error(
                "The dimension {} already exists",
                dimensionId,
                new Throwable()
            );
        }
    }
    
    public static class_2370<class_5363> getDimensionRegistry(MinecraftServer server) {
        return ((class_2370<class_5363>)
            server.method_30611().method_30530(class_7924.field_41224)
        );
    }
}
